// src/App.tsx
import React, { useEffect, useState } from "react";
import { useApp } from "./store";
import { FilterBar } from "./components/toolbar/FilterBar";
import { AddPoButton } from "./components/toolbar/AddPoButton";
import { AddPoModal } from "./components/toolbar/AddPoModal";
import { KpiStrip } from "./components/dashboard/KpiStrip";
import { Donuts } from "./components/dashboard/Donuts";
import { OrderTable } from "./components/dashboard/OrderTable";
import { KanbanBoard } from "./components/kanban/KanbanBoard";
import { Toaster } from "sonner";
import { Pump } from "./types";
import { Package, BarChart3, Layout } from "lucide-react";
import { Button } from "./components/ui/Button";

type View = "dashboard" | "kanban";

function App() {
  const { load, filtered } = useApp();
  const [isAddPoModalOpen, setIsAddPoModalOpen] = useState(false);
  const [currentView, setCurrentView] = useState<View>("dashboard");
  const [selectedPump, setSelectedPump] = useState<Pump | null>(null);

  useEffect(() => {
    load();
  }, [load]);

  const filteredPumps = filtered();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Package className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold">PumpTracker Lite</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={currentView === "dashboard" ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentView("dashboard")}
              >
                <BarChart3 className="h-4 w-4 mr-1" />
                Dashboard
              </Button>
              <Button
                variant={currentView === "kanban" ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentView("kanban")}
              >
                <Layout className="h-4 w-4 mr-1" />
                Kanban
              </Button>
              <AddPoButton onClick={() => setIsAddPoModalOpen(true)} />
            </div>
          </div>
        </div>
      </header>

      {/* Toolbar */}
      <FilterBar />

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {currentView === "dashboard" ? (
          <>
            <KpiStrip pumps={filteredPumps} />
            <Donuts pumps={filteredPumps} />
            <OrderTable pumps={filteredPumps} onRowClick={setSelectedPump} />
          </>
        ) : (
          <KanbanBoard pumps={filteredPumps} onCardClick={setSelectedPump} />
        )}
      </main>

      {/* Modals */}
      <AddPoModal
        isOpen={isAddPoModalOpen}
        onClose={() => setIsAddPoModalOpen(false)}
      />

      {/* Simple Pump Details Modal */}
      {selectedPump && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
          onClick={() => setSelectedPump(null)}
        >
          <div
            className="bg-card rounded-lg shadow-lg w-full max-w-md p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="text-xl font-semibold mb-4">Pump Details</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Serial:</span>
                <span className="font-medium">{selectedPump.serial}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">PO:</span>
                <span className="font-medium">{selectedPump.po}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Customer:</span>
                <span className="font-medium">{selectedPump.customer}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Model:</span>
                <span className="font-medium">{selectedPump.model}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Stage:</span>
                <span className="font-medium">{selectedPump.stage}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Priority:</span>
                <span className="font-medium">{selectedPump.priority}</span>
              </div>
              {selectedPump.powder_color && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Color:</span>
                  <span className="font-medium">{selectedPump.powder_color}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Value:</span>
                <span className="font-medium">${selectedPump.value.toLocaleString()}</span>
              </div>
              {selectedPump.scheduledEnd && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Scheduled End:</span>
                  <span className="font-medium">
                    {new Date(selectedPump.scheduledEnd).toLocaleDateString()}
                  </span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Last Update:</span>
                <span className="font-medium">
                  {new Date(selectedPump.last_update).toLocaleDateString()}
                </span>
              </div>
            </div>
            <div className="mt-6 flex justify-end">
              <Button onClick={() => setSelectedPump(null)}>Close</Button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notifications */}
      <Toaster position="top-right" />
    </div>
  );
}

export default App;
